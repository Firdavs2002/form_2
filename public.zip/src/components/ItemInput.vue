<template>
  <div class="input">
    <label :for="info.name">{{info.name}}</label>
    <input :type="info.type"
           :id="info.name"
           :placeholder="info.placeholder"
           v-model="info.value"
           required>
    </div>
</template>

<script>

export default {
    props: {
      info: {
        type: Object,
        required: true
      }
    }
}
</script>

<style scoped>
  .input {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
   }

  .input label {
    margin-right: 10px;
    display: inline-block;
    max-width: 100%;
    margin-bottom: 3px;
    color: #acacac;
    font-family: GothamPro, sans-serif;
    font-size: .8rem;
    font-weight: normal;
    line-height: 1.2rem;
   }

  .input input {
    display: block;
    width: 100%;
    max-height: 2.8rem;
    padding: .8rem 1rem;
    font-size: inherit;
    font-family: inherit;
    font-weight: inherit;
    line-height: 1.4;
    color: #000;
    background: #fff none;
    border: 1px solid #999;
    border-radius: 5px;
  }

  .input input:focus {
      box-shadow: 0 0 10px 5px #ee6f57;
  }
</style>